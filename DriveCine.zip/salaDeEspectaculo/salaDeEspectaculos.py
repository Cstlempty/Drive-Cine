import json

#Classe abstrata que instancia os objetos Assentos com seus atributos
class Assento:
    def __init__(self, nome=None, telefone=None, codAssento=None, ocupado=False):
        self.nome = nome
        self.telefone = telefone
        self.codAssento = codAssento
        self.ocupado = ocupado
        self.aSeguir = None

#Classe que herda de Assento para um instanciar um número fixo de objetos
class SalaDeEspectaculos(Assento):

    #receitas totais vão ser incrementadas toda vez que o atributo ocupado receber True
    receitaTotal = 0
    #dicionário em que as keys são nomes de clientes e os values são listas contendo as reservas dos mesmos
    reservaPorPessoa = {}
    #lista com os códigos dos assentos já reservados
    reservasTotais = []

    #O método de inicialização cria todos os assentos disponíveis
    def __init__(self, nome=None, telefone=None, codAssento=None , ocupado=False):
        super().__init__(nome, telefone, codAssento, ocupado)
        self.assento = Assento()
        codLetras = 'ABCDEFGHIJ'
        assentos = self.assento
        for letra in codLetras:
            for codNum in range(1, 19):
                assentos.aSeguir = Assento(codAssento=f'{letra}{codNum}')
                assentos = assentos.aSeguir

    #método que consulta todos os assentos disponíveis
    def listaDeAssentos(self):
        listaDeCodAssentos = []
        assentos = self.assento
        while assentos.aSeguir != None:
            assentos = assentos.aSeguir
            listaDeCodAssentos.append(assentos.codAssento)
        return listaDeCodAssentos

    #método que consulta um assento específico
    def consultarAssentos(self, codAssento):
        checagem = self.listaDeAssentos()
        if codAssento not in checagem:
            return print('Assento não existe')
        assentos = self.assento
        while assentos.aSeguir != None:
            assentos = assentos.aSeguir
            if codAssento == assentos.codAssento:
                informações = [assentos.nome, assentos.telefone, assentos.codAssento, f'ocupado: {assentos.ocupado}']
                return informações

    #método que cadastra uma reserva em nome de um cliente
    def reservarAssentos(self, codAssento, nome, telefone):
        checagem = self.listaDeAssentos()
        if codAssento not in checagem:
            return print('Assento não existe')
        assentos = self.assento
        while assentos.aSeguir != None:
            assentos = assentos.aSeguir
            if codAssento == assentos.codAssento:
                assentos.nome = nome
                assentos.telefone = telefone
                assentos.ocupado = True
                self.acrescentarNoSistema(codAssento, nome, telefone)
                return

    #método estático que visa incrementar as variáveis de classe
    def acrescentarNoSistema(self, codAssento, nome, telefone):
        if nome not in self.reservaPorPessoa.keys():
            self.reservaPorPessoa[nome] = []
            self.reservaPorPessoa[f'{nome}_telefones'] = []
        if telefone not in self.reservaPorPessoa[f'{nome}_telefones']:
            self.reservaPorPessoa[f'{nome}_telefones'].append(telefone)
        if codAssento not in self.reservaPorPessoa[nome]:
            self.reservaPorPessoa[nome].append(codAssento)
            self.receitaTotal += 5.00
            self.reservaPorPessoa['Receita total'] = self.receitaTotal
            self.reservasTotais.append(codAssento)
        return

    #método que retorna os atributos dos assentos para o estado padrão antes de terem sido reservados
    def liberarReserva(self, codAssento, nome, telefone):
        assentos = self.assento
        while assentos.aSeguir != None:
            assentos = assentos.aSeguir
            if codAssento == assentos.codAssento:
                assentos.nome = None
                assentos.ocupado = False
                self.decrescentarNoSistema(codAssento, nome, telefone)
                return

    #método estático que visa decrementar as variáveis de classe
    def decrescentarNoSistema(self, codAssento, nome, telefone):
        self.reservasTotais.remove(codAssento)
        self.receitaTotal -= 5.00
        self.reservaPorPessoa['Receita total'] = self.receitaTotal
        self.reservaPorPessoa[nome].remove(codAssento)
        self.removerTelefoneDeCliente(nome, telefone)
        return

    #método estático que apaga o número de telefone de determinado cliente
    def removerTelefoneDeCliente(self, nome, telefone):
        self.reservaPorPessoa[f'{nome}_telefones'].remove(telefone)
        if not self.reservaPorPessoa[f'{nome}_telefones']:
            del self.reservaPorPessoa[f'{nome}_telefones']
        if not self.reservaPorPessoa[nome]:
            del self.reservaPorPessoa[nome]
        return

    #método para settar telefone de clientes
    def adicionarTelefoneDeCliente(self, nome, novoNumero):
        if novoNumero not in self.reservaPorPessoa[f'{nome}_telefones']:
            self.reservaPorPessoa[f'{nome}_telefones'].append(novoNumero)
        return

    #método que imprime todas as variáveis de classe
    def gestaoDoSistema(self):
        print(f'Reservas totais\n{self.reservasTotais}')
        print(f'Receita total\n{self.receitaTotal}')
        print(f'Reserva por cliente\n{self.reservaPorPessoa}')
        return

    #método que salva em um ficheiro .txt os dados principais
    def salvar(self):
        with open("teste.txt", "w") as teste_file:
            return json.dump(self.reservaPorPessoa, teste_file)
    def abrir(self):
        with open("teste.txt", "r") as teste_file:
            data = json.load(teste_file)
            return data


#teatro = SalaDeEspectaculos()
#teatro.reservarAssentos('A17', 'vitor', 123456789)
#teatro.reservarAssentos('B11', 'rossana', 987654321)
#teatro.reservarAssentos('C10', 'vitor', 123456789)
#teatro.reservarAssentos('D12', 'rossana', 987654321)
#teatro.adicionarTelefoneDeCliente('vitor', 123123123)
#teatro.adicionarTelefoneDeCliente('rossana', 321321321)
#teatro.gestaoDoSistema()
#teatro.removerTelefoneDeCliente('vitor', 123123123)
#teatro.gestaoDoSistema()
