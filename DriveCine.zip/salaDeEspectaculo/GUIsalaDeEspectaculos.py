from tkinter import *
from tkinter.ttk import Combobox
import salaDeEspectaculos as sala

class Janela:
    def __init__(self, raiz):
        #Containers principais
        self.telaPrincipal = Frame(raiz)
        self.telaPrincipal.pack()

        #Fundo inicial
        self.fundoInicial = PhotoImage(file="theater_BG.png")
        self.labelFundoInicial = Label(self.telaPrincipal, image=self.fundoInicial)
        self.labelFundoInicial.pack()

        #Cores
        self.coresLista = ['IndiaRed1', 'thistle', 'medium sea green', 'light grey']

        #Cursores
        self.cursor = 'hand1'

        #Bordas
        self.bordasLista = ['groove', 'ridge', 'raised']

        #Imagem dos assentos
        self.imgAssentoDisponivel = PhotoImage(file="availableSeat.png")
        self.imgAssentoIndisponivel = PhotoImage(file="unavailableSeat.png")

        #botões
        letras = "ABCDEFGHIJ"
        self.assentosGUI = []
        aux = 0
        for j in range(10):
                letra = letras[j]
                for i in range(18):
                    obj = Button(self.telaPrincipal, border=0, image=self.imgAssentoDisponivel, text=f"{letra}{i+1}")
                    obj.configure(command=lambda botao = obj: self.popUpReserva(botao))
                    self.assentosGUI.append(obj)
                    self.assentosGUI[aux].place(x= 45 + 32 * i, y=60 * (j + 1))
                    aux +=1
                aux = 0
                aux = 18 * (j + 1)

    def popUpReserva(self, id):
        self.raizReserva = Toplevel()
        self.raizReserva.iconbitmap("minusIco.ico")
        self.raizReserva.title("Home > Reservas e Pagamentos")
        self.raizReserva.geometry("500x280+430+200")
        self.raizReserva.resizable(False, False)
        self.fundoCadastro = PhotoImage(file="registo.png")
        self.lbFundoCadastro = Label(self.raizReserva, image= self.fundoCadastro)
        self.lbFundoCadastro.pack(fill=BOTH, expand = True)
        self.entryNome = Entry(self.raizReserva, width=20, font=('Times', 16), bd=1, relief="sunken")
        self.entryNome.place(x = 30, y = 50)
        self.entryTelefone = Entry(self.raizReserva, width=20, font=('Times', 16), bd=1, relief="sunken")
        self.entryTelefone.place(x=30, y=120)
        self.pagamentoBotao = Button(self.raizReserva, text="Total a pagar", width=25, command=self.totalAPagar)
        self.pagamentoBotao.place(x=55, y=240)
        self.tabelaDePreçoBotao = Button(self.raizReserva, text="Preços", width=25, command=self.popUpTabelaDePreços)
        self.tabelaDePreçoBotao.place(x=55, y=200)
        self.reservarBotao = Button(self.raizReserva, text="Reservar", width=10, command=lambda:self.reservaOnClick(id))
        self.reservarBotao.place(x=40, y=150)
        self.liberarBotao = Button(self.raizReserva, text="Liberar", width=10, command=lambda: self.liberarOnClick(id))
        self.liberarBotao.place(x=160, y=150)
        consumoLista = ["Pipoca", "Refrigerante", "Chocolate", "Menu Pequeno", "Menu Médio", "Menu Grande"]
        self.consumoMenu = Combobox(self.raizReserva, values=consumoLista)
        self.consumoMenu.set("Produtos")
        self.consumoMenu.place(x=320, y=50)
        self.adicionarProdutoBotao = Button(self.raizReserva, text="Adicionar", width=10, command=self.adicionarProduto)
        self.adicionarProdutoBotao.place(x=320, y=75)
        self.labelTotalAPagar = Label(self.raizReserva, text="Total a pagar: ", padx="7m", pady="1.5m", bg="SteelBlue1",relief="groove")
        self.labelTotalAPagar.place(x=290, y=117)
        self.labelTotalAPagarResultado = Label(self.raizReserva, text="0", padx="7m", pady="1.5m", bg="gray94", relief="groove")
        self.labelTotalAPagarResultado.place(x=420, y=117)
        self.labelQuantidadeRecebida = Label(self.raizReserva, text="Total Recebido: ", padx="7m", pady="1.5m", bg="SteelBlue1", relief="groove")
        self.labelQuantidadeRecebida.place(x=290, y=152)
        self.entryQuantidadeRecebida = Entry(self.raizReserva, font=('Times', 18), bg="gray94", relief="groove", width=5)
        self.entryQuantidadeRecebida.place(x=420, y=152)
        self.labelTotalADevolver = Label(self.raizReserva, text="Total a devolver: ", padx="7m", pady="1.5m", bg="SteelBlue1", relief="groove")
        self.labelTotalADevolver.place(x=290, y=187)
        self.calcularBotao = Button(self.raizReserva, text="Calcular", width=25, command=self.calcular)
        self.calcularBotao.place(x=295, y=240)
        self.labelTotalADevolverResultado = Label(self.raizReserva, text="0", padx="7m", pady="1.5m",relief="groove")
        self.labelTotalADevolverResultado.place(x=420, y=187)

    def status(self, id):
        indice = self.assentosGUI.index(id)
        if self.assentosGUI[indice]["image"] == 'pyimage2':
                self.assentosGUI[indice]["image"] = self.imgAssentoIndisponivel
                return
        else:
                self.assentosGUI[indice]["image"] = self.imgAssentoDisponivel
                return

    def fecharReserva(self):
            self.raizReserva.destroy()
            return

    def reservaOnClick(self, id):
        nome = self.entryNome.get()
        telefone = self.entryTelefone.get()
        codAssento = id["text"]
        cinema.reservarAssentos(codAssento, nome, telefone)
        cinema.gestaoDoSistema()
        self.status(id)
        return

    def liberarOnClick(self, id):
        nome = self.entryNome.get()
        telefone = self.entryTelefone.get()
        codAssento = id["text"]
        cinema.liberarReserva(codAssento, nome, telefone)
        cinema.gestaoDoSistema()
        self.status(id)
        return

    def popUpTabelaDePreços(self):
        self.raizTabelaDePreço = Toplevel()
        self.raizTabelaDePreço.iconbitmap("minusIco.ico")
        self.raizTabelaDePreço.title("Home > Reservas e Pagamentos > Tabela de Preços")
        self.raizTabelaDePreço.geometry("500x280+430+200")
        self.raizTabelaDePreço.resizable(False, False)
        self.fundoTabela = PhotoImage(file="precos.png")
        self.lbFundoTabela = Label(self.raizTabelaDePreço, image=self.fundoTabela)
        self.lbFundoTabela.pack(fill=BOTH, expand=True)

    def adicionarProduto(self):
        nome = self.entryNome.get()
        if f'{nome}_consumo' not in cinema.reservaPorPessoa.keys():
            cinema.reservaPorPessoa[f'{nome}_consumo'] = []
        produto = self.consumoMenu.get()
        if produto == "Pipoca":
            preço = 2.85
        elif produto == "Refrigerante" or produto == "Chocolate":
            preço = 2.10
        elif produto == "Menu Pequeno":
            preço = 4.30
        elif produto == "Menu Médio":
            preço = 6.25
        elif produto == "Menu Grande":
            preço = 8.30
        cinema.receitaTotal += preço
        cinema.reservaPorPessoa[f'{nome}_consumo'] += [produto]
        cinema.gestaoDoSistema()
        return

    def totalAPagar(self):
        resultado = 0
        nome = self.entryNome.get()
        if f'{nome}_consumo' in cinema.reservaPorPessoa.keys():
            for produto in cinema.reservaPorPessoa[f'{nome}_consumo']:
                if produto == "Pipoca":
                    resultado += 2.85
                elif produto == "Refrigerante" or produto == "Chocolate":
                    resultado += 2.10
                elif produto == "Menu Pequeno":
                    resultado += 4.30
                elif produto == "Menu Médio":
                    resultado += 6.25
                elif produto == "Menu Grande":
                    resultado += 8.30
        if cinema.reservaPorPessoa[nome]:
            resultado += 5.00 * len(cinema.reservaPorPessoa[nome])
        self.labelTotalAPagarResultado["text"] = f'{resultado} €'
        return

    def calcular(self):
        resultado = 0
        pago = float(self.entryQuantidadeRecebida.get())
        aux = self.labelTotalAPagarResultado["text"]
        cobrança = aux.split()
        resultado = pago - float(cobrança[0])
        self.labelTotalADevolverResultado["text"] = '{:.2f} €'.format(resultado)
        return

cinema = sala.SalaDeEspectaculos()
raiz = Tk()
Janela(raiz)
raiz.resizable(False, False)
raiz.iconbitmap("minusIco.ico")
raiz.title("Home")
raiz.geometry("640x720+350+0")
raiz.minsize(600, 400)
raiz.mainloop()